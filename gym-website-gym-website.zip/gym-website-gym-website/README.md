# gym-website
Modern, animated, mobile-friendly Gym website built with HTML, CSS &amp; JavaScript. Includes smooth animations, contact section, and clean UI.
